import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Ticket, 
  LayoutDashboard, 
  ShoppingBag, 
  User as UserIcon, 
  Plus, 
  TrendingUp, 
  Users, 
  CheckCircle2, 
  Clock, 
  ChevronRight,
  Search,
  Filter,
  ArrowRight,
  CreditCard,
  QrCode,
  Menu,
  X,
  Settings as SettingsIcon,
  Shield,
  DollarSign,
  AlertCircle,
  Image as ImageIcon,
  Upload,
  Eye,
  EyeOff,
  Share2,
  Edit3,
  Gift,
  RotateCcw,
  Play
} from 'lucide-react';
import type { Campaign, User, Order } from './types';

// --- Helpers ---

const safeFetch = async (url: string, options?: RequestInit) => {
  try {
    const res = await fetch(url, options);
    const contentType = res.headers.get('content-type');
    
    if (res.ok && contentType && contentType.includes('application/json')) {
      return await res.json();
    }
    
    if (!res.ok) {
      const errorData = contentType && contentType.includes('application/json') 
        ? await res.json() 
        : { message: `Erro ${res.status}: ${res.statusText}` };
      throw new Error(errorData.message || 'Erro na requisição');
    }
    
    return null;
  } catch (err: any) {
    console.error(`Fetch error (${url}):`, err);
    throw err;
  }
};

// --- Components ---

const Navbar = ({ user, onLogout, onNavigate }: { user: User | null, onLogout: () => void, onNavigate: (page: string) => void }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <nav className="bg-white border-b border-zinc-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
            <div className="bg-emerald-600 p-2 rounded-lg">
              <Ticket className="text-white w-6 h-6" />
            </div>
            <span className="text-xl font-bold tracking-tight text-zinc-900">RifaPro</span>
          </div>

          {/* Desktop */}
          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => onNavigate('home')} className="text-sm font-medium text-zinc-600 hover:text-emerald-600 transition-colors">Explorar</button>
            {user ? (
              <>
                <button onClick={() => onNavigate('dashboard')} className="text-sm font-medium text-zinc-600 hover:text-emerald-600 transition-colors">Meu Painel</button>
                <div className="flex items-center gap-3 pl-4 border-l border-zinc-100">
                  <div className="text-right">
                    <p className="text-xs font-semibold text-zinc-900">{user.name}</p>
                    <button onClick={onLogout} className="text-[10px] text-zinc-400 hover:text-red-500 uppercase tracking-wider font-bold">Sair</button>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-700 font-bold text-xs">
                    {user.name.charAt(0)}
                  </div>
                </div>
              </>
            ) : (
              <button onClick={() => onNavigate('login')} className="bg-zinc-900 text-white px-5 py-2 rounded-full text-sm font-medium hover:bg-zinc-800 transition-all">
                Entrar / Criar Rifa
              </button>
            )}
          </div>

          {/* Mobile toggle */}
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="p-2 text-zinc-600">
              {isOpen ? <X /> : <Menu />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden bg-white border-t border-zinc-100 overflow-hidden"
          >
            <div className="px-4 py-6 space-y-4">
              <button onClick={() => { onNavigate('home'); setIsOpen(false); }} className="block w-full text-left text-lg font-medium text-zinc-900">Explorar</button>
              {user ? (
                <>
                  <button onClick={() => { onNavigate('dashboard'); setIsOpen(false); }} className="block w-full text-left text-lg font-medium text-zinc-900">Meu Painel</button>
                  <button onClick={() => { onLogout(); setIsOpen(false); }} className="block w-full text-left text-lg font-medium text-red-600">Sair</button>
                </>
              ) : (
                <button onClick={() => { onNavigate('login'); setIsOpen(false); }} className="block w-full text-center bg-zinc-900 text-white py-3 rounded-xl font-medium">Entrar</button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

const Sidebar = ({ activeTab, onNavigate, onLogout, user }: { activeTab: string, onNavigate: (tab: string) => void, onLogout: () => void, user: User }) => {
  const menuItems = [
    { id: 'dashboard', label: 'Home', icon: LayoutDashboard },
    { id: 'my-campaigns', label: 'Minhas campanhas', icon: Ticket },
    { id: 'supporters', label: 'Meus apoiadores', icon: Users },
    { id: 'affiliates', label: 'Gerenciar afiliados', icon: Users },
    { id: 'settings', label: 'Configuração', icon: SettingsIcon },
    { id: 'support', label: 'Suporte', icon: Shield },
    { id: 'course', label: 'Curso método 321', icon: ShoppingBag },
  ];

  return (
    <div className="w-72 bg-white border-r border-zinc-100 h-screen sticky top-0 flex flex-col p-6">
      <div className="flex items-center gap-2 mb-10 px-2">
        <div className="bg-brand-green p-1.5 rounded-lg">
          <Ticket className="text-white w-5 h-5" />
        </div>
        <span className="text-xl font-black tracking-tight text-zinc-900">RIFA <span className="text-brand-orange">321</span></span>
      </div>

      <button 
        onClick={() => onNavigate('create-campaign')}
        className="w-full btn-primary mb-8 flex items-center justify-center gap-2"
      >
        <Plus className="w-5 h-5" />
        Criar campanha
      </button>

      <nav className="flex-1 space-y-1">
        {menuItems.map((item) => (
          <button
            key={item.id}
            onClick={() => onNavigate(item.id)}
            className={`w-full sidebar-item ${activeTab === item.id ? 'active' : ''}`}
          >
            <item.icon className="w-5 h-5" />
            {item.label}
          </button>
        ))}
      </nav>

      <div className="pt-6 border-t border-zinc-100">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-600 font-bold">
            {user.name.charAt(0)}
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-zinc-900 truncate">{user.name}</p>
            <p className="text-xs text-zinc-400 truncate">{user.email}</p>
          </div>
        </div>
        <button onClick={onLogout} className="w-full py-2 text-xs font-bold text-red-500 hover:bg-red-50 uppercase tracking-widest rounded-xl transition-all">
          Sair da conta
        </button>
      </div>
    </div>
  );
};

const DashboardCard = ({ title, value, subValue, icon: Icon, colorClass }: { title: string, value: string, subValue?: string, icon: any, colorClass: string }) => (
  <div className={`glass-card p-8 flex items-center gap-6 flex-1 min-w-[300px] border-l-8 ${colorClass}`}>
    <div className="p-4 bg-zinc-50 rounded-2xl">
      <Icon className="w-8 h-8 text-zinc-400" />
    </div>
    <div>
      <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">{title}</p>
      <p className="text-3xl font-black text-zinc-900">{value}</p>
      {subValue && <p className="text-xs font-medium text-zinc-400 mt-1">{subValue}</p>}
    </div>
  </div>
);

const CampaignCard: React.FC<{ campaign: Campaign, onClick: () => void }> = ({ campaign, onClick }) => {
  const progress = (campaign.sold_count / campaign.total_tickets) * 100;
  
  return (
    <motion.div 
      whileHover={{ y: -5 }}
      className="bg-white rounded-3xl overflow-hidden border border-zinc-100 shadow-sm hover:shadow-xl transition-all cursor-pointer group"
      onClick={onClick}
    >
      <div className="aspect-video relative overflow-hidden">
        <img 
          src={campaign.image_url || `https://picsum.photos/seed/${campaign.id}/600/400`} 
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-4 left-4">
          <span className="bg-white/90 backdrop-blur px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider text-zinc-900">
            {campaign.draw_type === 'federal' ? 'Loteria Federal' : 'Sorteio Interno'}
          </span>
        </div>
      </div>
      
      <div className="p-6">
        <h3 className="text-xl font-black text-zinc-900 mb-2 group-hover:text-emerald-600 transition-colors">{campaign.title}</h3>
        <p className="text-zinc-500 text-sm line-clamp-2 mb-6 h-10">{campaign.description || 'Participe deste sorteio incrível e concorra a prêmios sensacionais!'}</p>
        
        <div className="space-y-4">
          <div className="flex justify-between items-end">
            <div>
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Por apenas</p>
              <p className="text-2xl font-black text-emerald-600">R$ {campaign.ticket_price.toFixed(2)}</p>
            </div>
            <div className="text-right">
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest mb-1">Sorteio em</p>
              <p className="text-sm font-bold text-zinc-900">{new Date(campaign.draw_date).toLocaleDateString()}</p>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest">
              <span className="text-emerald-600">{progress.toFixed(0)}% Vendido</span>
              <span className="text-zinc-400">{campaign.sold_count} / {campaign.total_tickets}</span>
            </div>
            <div className="h-2 bg-zinc-100 rounded-full overflow-hidden">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: `${progress}%` }}
                className="h-full bg-emerald-500"
              />
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

const CampaignRow: React.FC<{ campaign: Campaign, onSelect: (c: Campaign) => void, isDashboard?: boolean }> = ({ campaign, onSelect, isDashboard }) => {
  const progress = (campaign.sold_count / campaign.total_tickets) * 100;
  
  return (
    <div className="glass-card p-6 flex items-center gap-6 hover:shadow-md transition-all group">
      <div className="w-24 h-24 rounded-2xl overflow-hidden bg-zinc-100 shrink-0">
        <img src={campaign.image_url || `https://picsum.photos/seed/${campaign.id}/200/200`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
      </div>
      
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between mb-2">
          <h3 className="font-bold text-zinc-900 text-lg truncate">{campaign.title}</h3>
          <span className={`px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider ${
            campaign.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-orange-100 text-orange-700'
          }`}>
            {campaign.status === 'active' ? 'Ativa' : 'Pendente'}
          </span>
        </div>
        
        <p className="text-xs text-zinc-400 mb-4">Em andamento</p>
        
        <div className="flex items-center gap-4">
          <div className="flex-1 h-2 bg-zinc-100 rounded-full overflow-hidden">
            <div className="h-full bg-brand-green" style={{ width: `${progress}%` }} />
          </div>
          <span className="text-xs font-bold text-zinc-400">{progress.toFixed(2)}% vendido</span>
          <span className="text-xs font-bold text-zinc-900">{campaign.sold_count} de {campaign.total_tickets}</span>
        </div>
      </div>
      
      <button 
        onClick={() => onSelect(campaign)}
        className="px-6 py-2 text-brand-green font-bold text-xs uppercase tracking-widest hover:bg-emerald-50 rounded-xl transition-all"
      >
        {isDashboard ? 'EDITAR CAMPANHA' : 'Ver Página'}
      </button>
    </div>
  );
};

const ManageCampaign = ({ campaign, onBack, onView, onEdit }: { campaign: Campaign, onBack: () => void, onView: (c: Campaign) => void, onEdit: (c: Campaign) => void }) => {
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [showValue, setShowValue] = useState(false);
  const progress = (campaign.sold_count / campaign.total_tickets) * 100;

  const ActionButton = ({ icon: Icon, label, onClick, color = "text-zinc-600" }: any) => (
    <button 
      onClick={onClick}
      className="flex flex-col items-center justify-center gap-3 p-6 glass-card hover:border-brand-orange transition-all group"
    >
      <div className={`p-3 rounded-2xl bg-zinc-50 group-hover:bg-orange-50 transition-all ${color}`}>
        <Icon className="w-6 h-6" />
      </div>
      <span className="text-xs font-bold text-zinc-900">{label}</span>
    </button>
  );

  const Modal = ({ title, children, onClose }: any) => (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white rounded-[2.5rem] shadow-2xl w-full max-w-4xl overflow-hidden"
      >
        <div className="p-8 border-b border-zinc-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button onClick={onClose} className="p-2 hover:bg-zinc-50 rounded-xl transition-all">
              <ChevronRight className="rotate-180 w-5 h-5 text-zinc-400" />
            </button>
            <h2 className="text-2xl font-black text-zinc-900">{title}</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-zinc-50 rounded-xl transition-all">
            <X className="w-6 h-6 text-zinc-400" />
          </button>
        </div>
        <div className="p-8 max-h-[70vh] overflow-y-auto">
          {children}
        </div>
      </motion.div>
    </div>
  );

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-center">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-orange-50 rounded-2xl text-brand-orange">
            <SettingsIcon className="w-6 h-6" />
          </div>
          <h1 className="text-3xl font-black text-zinc-900">Gerenciar campanha</h1>
        </div>
        <button 
          onClick={onBack}
          className="bg-white border border-zinc-100 px-6 py-3 rounded-2xl text-zinc-400 font-bold text-sm flex items-center gap-2 hover:border-zinc-300 transition-all"
        >
          <ChevronRight className="w-4 h-4 rotate-180" /> Voltar
        </button>
      </header>

      <div className="flex gap-4">
        <button 
          onClick={() => onView(campaign)}
          className="p-4 glass-card hover:border-brand-orange transition-all text-zinc-400 hover:text-brand-orange"
        >
          <Eye className="w-5 h-5" />
        </button>
        <button onClick={() => setActiveModal('share')} className="p-4 glass-card hover:border-brand-orange transition-all text-zinc-400 hover:text-brand-orange">
          <Share2 className="w-5 h-5" />
        </button>
        <button 
          onClick={() => onEdit(campaign)}
          className="p-4 glass-card hover:border-brand-orange transition-all text-zinc-400 hover:text-brand-orange"
        >
          <Edit3 className="w-5 h-5" />
        </button>
      </div>

      <div className="glass-card p-10">
        <div className="flex flex-col lg:flex-row gap-10">
          <div className="w-full lg:w-72 h-72 rounded-[2.5rem] overflow-hidden bg-zinc-100 shrink-0">
            <img src={campaign.image_url || `https://picsum.photos/seed/${campaign.id}/400/400`} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
          </div>
          
          <div className="flex-1 space-y-8">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-3xl font-black text-zinc-900 mb-2">{campaign.title}</h2>
                <p className="text-zinc-400 font-bold">Em andamento</p>
              </div>
              <select className="bg-emerald-50 text-emerald-600 font-bold text-xs px-4 py-2 rounded-xl border-none outline-none cursor-pointer">
                <option value="active">Ativa</option>
                <option value="paused">Pausada</option>
                <option value="finished">Finalizada</option>
              </select>
            </div>

            <div className="space-y-4">
              <div className="h-3 bg-zinc-100 rounded-full overflow-hidden">
                <div className="h-full bg-brand-green" style={{ width: `${progress}%` }} />
              </div>
              <div className="flex justify-between text-sm font-bold">
                <span className="text-brand-green">{progress.toFixed(2)} % vendido</span>
                <span className="text-zinc-400">*** de {campaign.total_tickets}</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-6 border-t border-zinc-100">
              <div>
                <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Valor arrecadado</p>
                <div className="flex items-center gap-3">
                  <span className="text-3xl font-black text-brand-green">
                    {showValue ? `R$ ${(campaign.sold_count * campaign.ticket_price).toFixed(2)}` : 'R$ ****'}
                  </span>
                  <button onClick={() => setShowValue(!showValue)} className="text-zinc-300 hover:text-zinc-500 transition-all">
                    {showValue ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-4 mt-12">
          <ActionButton icon={DollarSign} label="Minhas vendas" onClick={() => setActiveModal('sales')} />
          <ActionButton icon={Ticket} label="Título premiado" onClick={() => setActiveModal('winning-tickets')} />
          <ActionButton icon={TrendingUp} label="Ranking" onClick={() => setActiveModal('ranking')} />
          <ActionButton icon={Search} label="Maior e Menor título" onClick={() => setActiveModal('min-max-tickets')} />
          <ActionButton icon={Gift} label="Caixa Premiada" onClick={() => {}} />
          <ActionButton icon={RotateCcw} label="Roleta Premiada" onClick={() => {}} />
          <ActionButton icon={LayoutDashboard} label="Realizar sorteio" onClick={() => {}} />
        </div>
      </div>

      <AnimatePresence>
        {activeModal === 'sales' && (
          <Modal title="Minhas vendas" onClose={() => setActiveModal(null)}>
            <div className="space-y-6">
              <div className="flex flex-wrap gap-4">
                <div className="flex-1 min-w-[200px] relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 w-4 h-4" />
                  <input type="text" placeholder="Buscar..." className="w-full h-12 bg-zinc-50 border border-zinc-100 rounded-xl pl-10 pr-4 text-sm outline-none focus:ring-2 focus:ring-brand-orange" />
                </div>
                <button className="px-6 h-12 glass-card flex items-center gap-2 text-sm font-bold text-zinc-600"><Filter className="w-4 h-4" /> Filtro</button>
                <button className="px-6 h-12 glass-card flex items-center gap-2 text-sm font-bold text-zinc-600"><TrendingUp className="w-4 h-4" /> Relatório</button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-zinc-900 text-white text-[10px] uppercase tracking-widest font-bold">
                      <th className="p-4 rounded-l-xl">Apoiador</th>
                      <th className="p-4">Data</th>
                      <th className="p-4">Origem</th>
                      <th className="p-4">Valor</th>
                      <th className="p-4">Títulos</th>
                      <th className="p-4">Status</th>
                      <th className="p-4 rounded-r-xl">Ação</th>
                    </tr>
                  </thead>
                  <tbody className="text-sm font-medium text-zinc-600">
                    {[1,2,3,4,5].map(i => (
                      <tr key={i} className="border-b border-zinc-50 hover:bg-zinc-50 transition-all">
                        <td className="p-4 text-zinc-900 font-bold">Janice Rêgo</td>
                        <td className="p-4 text-xs">17/10/2025, 18:59</td>
                        <td className="p-4 text-xs">Direto</td>
                        <td className="p-4 text-zinc-900 font-bold">R$ 50,00</td>
                        <td className="p-4">5</td>
                        <td className="p-4">
                          <span className="px-3 py-1 bg-emerald-50 text-emerald-600 rounded-lg text-[10px] font-bold uppercase">Aprovado</span>
                        </td>
                        <td className="p-4">
                          <button className="p-2 hover:bg-zinc-100 rounded-lg transition-all text-brand-orange"><Eye className="w-4 h-4" /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </Modal>
        )}

        {activeModal === 'winning-tickets' && (
          <Modal title="Título premiado" onClose={() => setActiveModal(null)}>
            <div className="space-y-8">
              <div className="flex items-center justify-between p-6 bg-zinc-50 rounded-3xl">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-6 bg-zinc-200 rounded-full relative cursor-pointer">
                    <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm" />
                  </div>
                  <span className="text-sm font-bold text-zinc-600">Deixar o bilhete premiado visível para os participantes</span>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex bg-zinc-100 p-1 rounded-2xl">
                  <button className="px-8 py-3 rounded-xl text-sm font-bold bg-white text-brand-orange shadow-sm">Todos</button>
                  <button className="px-8 py-3 rounded-xl text-sm font-bold text-zinc-400">Disponível</button>
                  <button className="px-8 py-3 rounded-xl text-sm font-bold text-zinc-400">Encontrado</button>
                </div>
                <button onClick={() => setActiveModal('add-winning-ticket')} className="bg-brand-orange text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-600 transition-all">
                  Cadastrar título
                </button>
              </div>
              <div className="py-20 flex flex-col items-center text-center">
                <div className="w-24 h-24 bg-zinc-50 rounded-full flex items-center justify-center mb-6">
                  <Ticket className="w-10 h-10 text-zinc-200" />
                </div>
                <h3 className="text-xl font-black text-zinc-900 mb-2">Nenhum título encontrado</h3>
                <p className="text-zinc-400 font-medium mb-8">Clique em cadastrar título</p>
                <button className="flex items-center gap-2 text-brand-orange font-bold border-2 border-brand-orange px-8 py-3 rounded-2xl hover:bg-orange-50 transition-all">
                  <Play className="w-4 h-4 fill-current" /> Ver como funciona
                </button>
              </div>
            </div>
          </Modal>
        )}

        {activeModal === 'add-winning-ticket' && (
          <Modal title="Cadastrar título premiado" onClose={() => setActiveModal('winning-tickets')}>
            <form className="space-y-6 max-w-md mx-auto py-8">
              <div>
                <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Título</label>
                <input type="text" placeholder="000" className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange" />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Prêmio</label>
                <input type="text" placeholder="Nome do prêmio" className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange" />
              </div>
              <button className="w-full bg-brand-orange text-white py-5 rounded-2xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-600 transition-all">
                Cadastrar
              </button>
            </form>
          </Modal>
        )}

        {activeModal === 'ranking' && (
          <Modal title="Ranking" onClose={() => setActiveModal(null)}>
            <div className="space-y-8">
              <div className="flex items-center justify-between">
                <div className="relative w-72">
                  <Clock className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 w-4 h-4" />
                  <input type="text" placeholder="Filtro de data" className="w-full h-14 bg-zinc-50 border border-zinc-100 rounded-2xl pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-brand-orange" />
                </div>
                <button onClick={() => setActiveModal('add-ranking-prize')} className="bg-brand-orange text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-600 transition-all">
                  Cadastrar prêmio
                </button>
              </div>
              <div className="flex items-center gap-4 p-6 bg-zinc-50 rounded-3xl">
                <div className="w-12 h-6 bg-brand-orange rounded-full relative cursor-pointer">
                  <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm" />
                </div>
                <span className="text-sm font-bold text-zinc-600">Deixar o ranking visível para os participantes</span>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { name: 'ORIDES RAMOS DA SILVA FILHO', tickets: 10, rank: 1 },
                  { name: 'Clécio Ribeiro', tickets: 10, rank: 2 },
                  { name: 'SILVANEIA FERREIRA BASTOS', tickets: 6, rank: 3 },
                  { name: 'Neuma Araújo', tickets: 6, rank: 4 },
                  { name: 'VALDECILO PEREIRA LIMA JUNIOR', tickets: 5, rank: 5 },
                  { name: 'CLEMILSON BASTOS DOS SANTOS', tickets: 5, rank: 6 },
                ].map((item, i) => (
                  <div key={i} className="p-6 glass-card flex items-center justify-between group hover:border-brand-orange transition-all">
                    <div className="flex items-center gap-4">
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-lg ${
                        item.rank === 1 ? 'bg-yellow-100 text-yellow-600' : 
                        item.rank === 2 ? 'bg-zinc-100 text-zinc-400' : 
                        item.rank === 3 ? 'bg-orange-100 text-orange-600' : 'text-zinc-900'
                      }`}>
                        {item.rank === 1 ? '🥇' : item.rank === 2 ? '🥈' : item.rank === 3 ? '🥉' : `${item.rank}º`}
                      </div>
                      <span className="font-bold text-zinc-900 text-sm truncate max-w-[180px]">{item.name}</span>
                    </div>
                    <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-50 text-emerald-600 rounded-xl">
                      <Ticket className="w-4 h-4" />
                      <span className="text-xs font-black">{item.tickets}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </Modal>
        )}

        {activeModal === 'add-ranking-prize' && (
          <Modal title="Prêmio top apoiador" onClose={() => setActiveModal('ranking')}>
            <form className="space-y-6 max-w-md mx-auto py-8">
              <div>
                <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Prêmio</label>
                <input type="text" placeholder="Nome do prêmio" className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange" />
              </div>
              <button className="w-full bg-brand-orange text-white py-5 rounded-2xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-600 transition-all">
                Adicionar prêmio
              </button>
            </form>
          </Modal>
        )}

        {activeModal === 'min-max-tickets' && (
          <Modal title="Maior e Menor título" onClose={() => setActiveModal(null)}>
            <div className="space-y-8">
              <div className="flex bg-zinc-100 p-1 rounded-2xl">
                <button className="flex-1 py-4 rounded-xl text-sm font-bold bg-white text-brand-orange shadow-sm">Filtrar por dia</button>
                <button className="flex-1 py-4 rounded-xl text-sm font-bold text-zinc-400">Filtrar por período</button>
              </div>
              <div className="space-y-6">
                <div>
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Filtrar por dia</label>
                  <div className="relative">
                    <Clock className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 w-4 h-4" />
                    <input type="text" defaultValue="24/02/2026" className="w-full h-14 bg-zinc-50 border border-zinc-100 rounded-2xl pl-12 pr-4 text-sm outline-none focus:ring-2 focus:ring-brand-orange" />
                  </div>
                </div>
                <div className="space-y-4">
                  <p className="font-bold text-zinc-900">Busca por:</p>
                  <div className="flex flex-col gap-3">
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <div className="w-5 h-5 border-2 border-zinc-200 rounded flex items-center justify-center group-hover:border-brand-orange transition-all">
                        <div className="w-2.5 h-2.5 bg-brand-orange rounded-sm" />
                      </div>
                      <span className="text-sm font-bold text-zinc-600">Menor título</span>
                    </label>
                    <label className="flex items-center gap-3 cursor-pointer group">
                      <div className="w-5 h-5 border-2 border-zinc-200 rounded flex items-center justify-center group-hover:border-brand-orange transition-all" />
                      <span className="text-sm font-bold text-zinc-600">Maior título</span>
                    </label>
                  </div>
                </div>
                <button className="w-full bg-brand-orange text-white py-5 rounded-2xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-600 transition-all">
                  Buscar
                </button>
              </div>
              <div className="pt-8 border-t border-zinc-100">
                <h3 className="font-bold text-zinc-900 mb-8">Resultado</h3>
                <div className="py-12 flex flex-col items-center text-center">
                  <div className="w-20 h-20 bg-zinc-50 rounded-full flex items-center justify-center mb-4">
                    <Ticket className="w-8 h-8 text-zinc-200" />
                  </div>
                </div>
              </div>
            </div>
          </Modal>
        )}

        {activeModal === 'share' && (
          <Modal title="Compartilhar campanha" onClose={() => setActiveModal(null)}>
            <div className="space-y-8">
              <div className="grid grid-cols-3 gap-4">
                <button className="h-20 glass-card flex flex-col items-center justify-center gap-2 text-emerald-500 hover:bg-emerald-50 transition-all">
                  <div className="w-10 h-10 bg-emerald-100 rounded-full flex items-center justify-center">
                    <Users className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-bold uppercase">Whatsapp</span>
                </button>
                <button className="h-20 glass-card flex flex-col items-center justify-center gap-2 text-blue-600 hover:bg-blue-50 transition-all">
                  <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                    <LayoutDashboard className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-bold uppercase">Facebook</span>
                </button>
                <button className="h-20 glass-card flex flex-col items-center justify-center gap-2 text-sky-500 hover:bg-sky-50 transition-all">
                  <div className="w-10 h-10 bg-sky-100 rounded-full flex items-center justify-center">
                    <TrendingUp className="w-5 h-5" />
                  </div>
                  <span className="text-[10px] font-bold uppercase">Telegram</span>
                </button>
              </div>
              <div className="space-y-6">
                <div>
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Mensagem personalizada</label>
                  <div className="relative">
                    <input type="text" placeholder="Olá, gostaria de te convidar a..." className="w-full h-14 bg-zinc-50 border border-zinc-100 rounded-2xl px-6 pr-12 text-sm outline-none focus:ring-2 focus:ring-brand-orange" />
                    <Edit3 className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-300 w-4 h-4" />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Mensagem para grupos de Whatsapp</label>
                  <div className="relative">
                    <input type="text" placeholder="🚨 PARA PARTICIPAR CLIQUE NO LINK ABAIXO..." className="w-full h-14 bg-zinc-50 border border-zinc-100 rounded-2xl px-6 pr-12 text-sm outline-none focus:ring-2 focus:ring-brand-orange" />
                    <Edit3 className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-300 w-4 h-4" />
                  </div>
                </div>
                <button className="w-full h-14 glass-card flex items-center justify-center gap-2 font-bold text-zinc-600 hover:border-brand-orange transition-all">
                  <Share2 className="w-4 h-4" /> Copiar link
                </button>
                <button className="w-full h-14 glass-card flex items-center justify-center gap-2 font-bold text-zinc-600 hover:border-brand-orange transition-all">
                  <QrCode className="w-4 h-4" /> Gerar QRCode
                </button>
              </div>
            </div>
          </Modal>
        )}
      </AnimatePresence>
    </div>
  );
};

// --- Pages ---

const HomePage = ({ campaigns, onSelectCampaign }: { campaigns: Campaign[], onSelectCampaign: (c: Campaign) => void }) => {
  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <header className="mb-12 text-center max-w-2xl mx-auto">
        <motion.h1 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-4xl md:text-5xl font-black text-zinc-900 tracking-tight mb-4"
        >
          Participe dos Melhores <span className="text-emerald-600">Sorteios Online</span>
        </motion.h1>
        <p className="text-zinc-500 text-lg">Campanhas auditadas, seguras e com premiações incríveis. Escolha sua sorte!</p>
      </header>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {campaigns.map((campaign) => (
          <CampaignCard key={campaign.id} campaign={campaign} onClick={() => onSelectCampaign(campaign)} />
        ))}
      </div>
    </div>
  );
};

const CampaignDetails = ({ campaign, onBack }: { campaign: Campaign, onBack: () => void }) => {
  const [quantity, setQuantity] = useState(1);
  const [step, setStep] = useState<'details' | 'checkout' | 'payment'>('details');
  const [orderData, setOrderData] = useState({ name: '', email: '', phone: '' });

  const handlePurchase = async () => {
    try {
      const data = await safeFetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          campaign_id: campaign.id,
          customer_name: orderData.name,
          customer_email: orderData.email,
          customer_phone: orderData.phone,
          ticket_count: quantity,
          payment_method: 'pix'
        })
      });
      if (data && data.success) {
        setStep('payment');
      } else {
        alert(data?.message || 'Erro ao processar pedido');
      }
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 py-12">
      <button onClick={onBack} className="flex items-center gap-2 text-zinc-500 hover:text-zinc-900 mb-8 transition-colors">
        <ChevronRight className="rotate-180 w-4 h-4" />
        <span className="text-sm font-medium">Voltar para explorar</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Left: Info */}
        <div className="space-y-8">
          <div className="rounded-3xl overflow-hidden border border-zinc-100 shadow-xl">
            <img 
              src={campaign.image_url || `https://picsum.photos/seed/${campaign.id}/1200/800`} 
              alt={campaign.title}
              className="w-full aspect-video object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h1 className="text-3xl font-black text-zinc-900 mb-4">{campaign.title}</h1>
            <div className="prose prose-zinc max-w-none text-zinc-600">
              {campaign.description}
            </div>
          </div>
        </div>

        {/* Right: Checkout */}
        <div className="bg-white rounded-3xl border border-zinc-100 p-8 shadow-xl h-fit sticky top-24">
          <AnimatePresence mode="wait">
            {step === 'details' && (
              <motion.div 
                key="details"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <div className="flex justify-between items-end">
                  <div>
                    <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Preço Unitário</p>
                    <p className="text-3xl font-black text-emerald-600">R$ {campaign.ticket_price.toFixed(2)}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-1">Sorteio em</p>
                    <p className="text-sm font-bold text-zinc-900">{new Date(campaign.draw_date).toLocaleDateString()}</p>
                  </div>
                </div>

                <div className="bg-zinc-50 rounded-2xl p-6 space-y-4">
                  <p className="text-sm font-bold text-zinc-900">Quantos números deseja?</p>
                  <div className="grid grid-cols-4 gap-2">
                    {[5, 10, 20, 50].map(n => (
                      <button 
                        key={n}
                        onClick={() => setQuantity(n)}
                        className={`py-2 rounded-xl text-sm font-bold transition-all ${quantity === n ? 'bg-emerald-600 text-white' : 'bg-white border border-zinc-200 text-zinc-600 hover:border-emerald-600'}`}
                      >
                        +{n}
                      </button>
                    ))}
                  </div>
                  <div className="flex items-center gap-4">
                    <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="w-12 h-12 rounded-xl border border-zinc-200 flex items-center justify-center text-xl font-bold">-</button>
                    <input 
                      type="number" 
                      value={isNaN(quantity) ? '' : quantity} 
                      onChange={(e) => setQuantity(parseInt(e.target.value) || 0)}
                      className="flex-1 h-12 rounded-xl border border-zinc-200 text-center font-bold text-lg focus:ring-2 focus:ring-emerald-500 outline-none"
                    />
                    <button onClick={() => setQuantity(quantity + 1)} className="w-12 h-12 rounded-xl border border-zinc-200 flex items-center justify-center text-xl font-bold">+</button>
                  </div>
                </div>

                <div className="pt-4 border-t border-zinc-100">
                  <div className="flex justify-between items-center mb-6">
                    <span className="text-zinc-500 font-medium">Total a pagar</span>
                    <span className="text-2xl font-black text-zinc-900">R$ {(campaign.ticket_price * quantity).toFixed(2)}</span>
                  </div>
                  <button 
                    onClick={() => setStep('checkout')}
                    className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold text-lg shadow-lg shadow-emerald-200 hover:bg-emerald-700 transition-all flex items-center justify-center gap-2"
                  >
                    Participar Agora <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              </motion.div>
            )}

            {step === 'checkout' && (
              <motion.div 
                key="checkout"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="space-y-6"
              >
                <h2 className="text-2xl font-black text-zinc-900">Seus Dados</h2>
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Nome Completo</label>
                    <input 
                      type="text" 
                      placeholder="Ex: João Silva"
                      className="w-full h-12 rounded-xl border border-zinc-200 px-4 font-medium focus:ring-2 focus:ring-emerald-500 outline-none"
                      value={orderData.name}
                      onChange={e => setOrderData({...orderData, name: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">E-mail</label>
                    <input 
                      type="email" 
                      placeholder="joao@email.com"
                      className="w-full h-12 rounded-xl border border-zinc-200 px-4 font-medium focus:ring-2 focus:ring-emerald-500 outline-none"
                      value={orderData.email}
                      onChange={e => setOrderData({...orderData, email: e.target.value})}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">WhatsApp</label>
                    <input 
                      type="tel" 
                      placeholder="(11) 99999-9999"
                      className="w-full h-12 rounded-xl border border-zinc-200 px-4 font-medium focus:ring-2 focus:ring-emerald-500 outline-none"
                      value={orderData.phone}
                      onChange={e => setOrderData({...orderData, phone: e.target.value})}
                    />
                  </div>
                </div>

                <div className="pt-4 space-y-3">
                  <button 
                    onClick={handlePurchase}
                    disabled={!orderData.name || !orderData.email || !orderData.phone}
                    className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold text-lg shadow-lg disabled:opacity-50 hover:bg-emerald-700 transition-all"
                  >
                    Confirmar e Pagar
                  </button>
                  <button onClick={() => setStep('details')} className="w-full text-zinc-400 font-bold text-sm py-2">Voltar</button>
                </div>
              </motion.div>
            )}

            {step === 'payment' && (
              <motion.div 
                key="payment"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center space-y-6"
              >
                <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto">
                  <QrCode className="text-emerald-600 w-10 h-10" />
                </div>
                <div>
                  <h2 className="text-2xl font-black text-zinc-900">Pagamento via PIX</h2>
                  <p className="text-zinc-500 text-sm mt-2">Escaneie o QR Code abaixo ou copie o código para pagar.</p>
                </div>
                
                <div className="aspect-square bg-zinc-100 rounded-2xl flex items-center justify-center border-2 border-dashed border-zinc-200">
                  <p className="text-zinc-400 font-mono text-xs">[QR CODE MOCK]</p>
                </div>

                <button className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold">Copiar Código PIX</button>
                
                <div className="flex items-center justify-center gap-2 text-emerald-600 font-bold text-sm">
                  <Clock className="w-4 h-4" />
                  Aguardando confirmação...
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
};

const CreateCampaignModal = ({ user, onClose, onCreated, initialData }: { user: User, onClose: () => void, onCreated: () => void, initialData?: Campaign }) => {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imagePreview, setImagePreview] = useState<string | null>(initialData?.image_url || null);
  const [formData, setFormData] = useState({
    title: initialData?.title || '',
    description: initialData?.description || '',
    slug: initialData?.slug || '',
    image_url: initialData?.image_url || '',
    ticket_price: initialData?.ticket_price || 10,
    total_tickets: initialData?.total_tickets || 100,
    draw_date: initialData?.draw_date || '',
    draw_type: initialData?.draw_type || 'federal',
    display_mode: initialData?.display_mode || 'random'
  });

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        setImagePreview(base64String);
        setFormData({ ...formData, image_url: base64String });
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (step < 3) {
      setStep(step + 1);
      return;
    }

    setIsSubmitting(true);
    try {
      const url = initialData ? `/api/campaigns/${initialData.id}` : '/api/campaigns';
      const method = initialData ? 'PUT' : 'POST';
      
      const data = await safeFetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          organizer_id: user.id
        })
      });

      if (data && data.success) {
        onCreated();
        onClose();
      }
    } catch (err: any) {
      alert(err.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const steps = [
    { id: 1, label: 'Informações' },
    { id: 2, label: 'Regulamento' },
    { id: 3, label: 'Modo/Resultado' }
  ];

  return (
    <div className="fixed inset-0 bg-zinc-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="bg-white w-full max-w-4xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        <div className="p-8 border-b border-zinc-100 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="w-10 h-10 bg-brand-orange/10 rounded-full flex items-center justify-center text-brand-orange">
              {initialData ? <Edit3 className="w-6 h-6" /> : <Plus className="w-6 h-6" />}
            </div>
            <h2 className="text-2xl font-black text-zinc-900">{initialData ? 'Editar campanha' : 'Criar campanha'}</h2>
          </div>
          <button onClick={onClose} className="bg-zinc-50 p-3 rounded-2xl text-zinc-400 hover:text-zinc-600 transition-all flex items-center gap-2 font-bold text-xs uppercase tracking-widest">
            <ArrowRight className="w-4 h-4 rotate-180" /> Voltar
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-8">
          {/* Steps Indicator */}
          <div className="flex items-center justify-center gap-12 mb-12">
            {steps.map((s) => (
              <div key={s.id} className="flex items-center gap-3">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm transition-all ${
                  step === s.id ? 'bg-brand-orange text-white shadow-lg shadow-orange-100' : 
                  step > s.id ? 'bg-brand-green text-white' : 'bg-zinc-100 text-zinc-400'
                }`}>
                  {step > s.id ? <CheckCircle2 className="w-5 h-5" /> : s.id}
                </div>
                <span className={`font-bold text-sm ${step === s.id ? 'text-zinc-900' : 'text-zinc-400'}`}>{s.label}</span>
                {s.id < 3 && <div className="w-24 h-1 bg-zinc-100 rounded-full overflow-hidden">
                  <div className={`h-full bg-brand-orange transition-all duration-500 ${step > s.id ? 'w-full' : 'w-0'}`} />
                </div>}
              </div>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="space-y-8">
            {step === 1 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-4">
                <div className="space-y-6">
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Nome da campanha</label>
                    <input 
                      required
                      type="text" 
                      className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange"
                      value={formData.title}
                      onChange={e => setFormData({...formData, title: e.target.value, slug: e.target.value.toLowerCase().replace(/ /g, '-')})}
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Quantidade de títulos</label>
                    <select 
                      className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange bg-white"
                      value={isNaN(formData.total_tickets) ? '' : formData.total_tickets}
                      onChange={e => setFormData({...formData, total_tickets: parseInt(e.target.value) || 0})}
                    >
                      <option value="100">100 títulos - (00 à 99)</option>
                      <option value="1000">1000 títulos - (000 à 999)</option>
                      <option value="10000">10000 títulos - (0000 à 9999)</option>
                    </select>
                  </div>
                </div>
                <div className="space-y-6">
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Por onde será extraído o resultado?</label>
                    <select 
                      className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange bg-white"
                      value={formData.draw_type}
                      onChange={e => setFormData({...formData, draw_type: e.target.value})}
                    >
                      <option value="federal">Loteria Federal</option>
                      <option value="internal">Sorteio Interno</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Valor de cada título</label>
                    <div className="flex">
                      <div className="h-14 px-6 bg-brand-orange text-white flex items-center font-bold rounded-l-2xl">R$</div>
                      <input 
                        required
                        type="number" 
                        step="0.01"
                        className="flex-1 h-14 rounded-r-2xl border border-zinc-200 px-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange"
                        value={isNaN(formData.ticket_price) ? '' : formData.ticket_price}
                        onChange={e => setFormData({...formData, ticket_price: parseFloat(e.target.value)})}
                      />
                    </div>
                  </div>
                </div>
                <div className="md:col-span-2 bg-zinc-50 p-6 rounded-3xl">
                  <p className="text-sm font-bold text-zinc-600">A sua arrecadação estimada é de: <span className="text-brand-green">R$ {(formData.total_tickets * formData.ticket_price).toFixed(2)}</span></p>
                  <p className="text-xs text-zinc-400 mt-1">Taxa: R$ 47,00 <span className="text-brand-orange cursor-pointer ml-2">Ver tabela de taxa →</span></p>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4">
                <div>
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-4 block">Adicione uma foto</label>
                  <label className="w-full h-48 rounded-[2rem] border-2 border-dashed border-zinc-200 flex flex-col items-center justify-center cursor-pointer hover:border-brand-orange hover:bg-orange-50 transition-all overflow-hidden relative">
                    {imagePreview ? (
                      <img src={imagePreview} className="w-full h-full object-cover" />
                    ) : (
                      <>
                        <div className="w-12 h-12 bg-zinc-100 rounded-2xl flex items-center justify-center text-zinc-400 mb-3">
                          <Plus className="w-6 h-6" />
                        </div>
                        <span className="text-sm font-bold text-brand-orange">Adicione uma imagem</span>
                      </>
                    )}
                    <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                  </label>
                </div>
                <div>
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Prazo para uma reserva expirar</label>
                  <select className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange bg-white">
                    <option>1 hora</option>
                    <option>24 horas</option>
                    <option>48 horas</option>
                  </select>
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Quantidade mínima de títulos</label>
                    <input type="number" defaultValue="1" className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none" />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Quantidade máxima de títulos</label>
                    <input type="number" className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none" />
                  </div>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 animate-in fade-in slide-in-from-bottom-4">
                <div className="glass-card p-8 space-y-6">
                  <div className="flex items-center gap-2 mb-4">
                    <LayoutDashboard className="text-brand-orange w-5 h-5" />
                    <h3 className="font-bold text-zinc-900">Modo</h3>
                  </div>
                  <div className="flex bg-zinc-100 p-1 rounded-2xl">
                    <button type="button" className="flex-1 py-3 rounded-xl text-sm font-bold bg-white text-brand-orange shadow-sm">Títulos Aleatórios</button>
                    <button type="button" className="flex-1 py-3 rounded-xl text-sm font-bold text-zinc-400">Títulos Expostos</button>
                  </div>
                  <p className="text-xs text-zinc-400 text-center">As cotas são selecionadas aleatoriamente</p>
                  <div className="grid grid-cols-5 gap-2 opacity-50">
                    {[1,2,3,4,5,6,7,8,9,10].map(i => (
                      <div key={i} className="aspect-square border border-zinc-200 rounded-lg flex items-center justify-center text-[10px] font-bold text-zinc-400">00{i}</div>
                    ))}
                  </div>
                </div>
                <div className="space-y-6">
                  <div className="glass-card p-6 flex items-center gap-4 hover:border-brand-orange cursor-pointer transition-all">
                    <div className="p-3 bg-orange-50 rounded-xl text-brand-orange"><Plus className="w-5 h-5" /></div>
                    <span className="font-bold text-zinc-600">Adicionar prêmios</span>
                  </div>
                  <div className="glass-card p-6 flex items-center gap-4 hover:border-brand-orange cursor-pointer transition-all">
                    <div className="p-3 bg-orange-50 rounded-xl text-brand-orange"><Plus className="w-5 h-5" /></div>
                    <span className="font-bold text-zinc-600">Adicionar promoção</span>
                  </div>
                  <div className="glass-card p-8 space-y-4">
                    <div className="flex items-center gap-2">
                      <Clock className="text-brand-orange w-5 h-5" />
                      <h3 className="font-bold text-zinc-900">Data do sorteio</h3>
                    </div>
                    <div className="flex bg-zinc-100 p-1 rounded-2xl">
                      <button type="button" className="flex-1 py-3 rounded-xl text-sm font-bold text-zinc-400">Já tenho data</button>
                      <button type="button" className="flex-1 py-3 rounded-xl text-sm font-bold bg-white text-brand-orange shadow-sm">Não tenho data</button>
                    </div>
                  </div>
                </div>
              </div>
            )}

            <div className="pt-8 flex gap-4">
              {step > 1 && (
                <button 
                  type="button" 
                  onClick={() => setStep(step - 1)} 
                  className="px-8 py-4 rounded-2xl font-bold text-zinc-500 bg-zinc-100 hover:bg-zinc-200 transition-all flex items-center gap-2"
                >
                  <ArrowRight className="w-4 h-4 rotate-180" /> Voltar
                </button>
              )}
              <button 
                type="submit" 
                disabled={isSubmitting}
                className="flex-1 bg-brand-green text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-100 hover:scale-[1.02] active:scale-[0.98] transition-all disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                ) : (
                  <>
                    {step === 3 ? 'Finalizar' : 'Continuar'}
                    <ArrowRight className="w-5 h-5" />
                  </>
                )}
              </button>
            </div>
          </form>
        </div>
      </motion.div>
    </div>
  );
};

const SuperAdminDashboard = ({ user }: { user: User }) => {
  const [stats, setStats] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [settings, setSettings] = useState<any>({});
  const [activeTab, setActiveTab] = useState<'stats' | 'users' | 'settings'>('stats');

  const fetchData = async () => {
    if (!user?.id) return;
    try {
      const statsData = await safeFetch(`/api/admin/stats/${user.id}`);
      if (statsData) setStats(statsData);

      const usersData = await safeFetch('/api/admin/users');
      if (usersData) setUsers(usersData);

      const settingsData = await safeFetch('/api/settings');
      if (settingsData) setSettings(settingsData);
    } catch (err) {
      console.error('Erro ao buscar dados do super admin:', err);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user.id]);

  const handleUpdateSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await safeFetch('/api/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(settings)
      });
      alert('Configurações atualizadas!');
    } catch (err: any) {
      alert(err.message);
    }
  };

  const toggleUserStatus = async (userId: number, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'suspended' : 'active';
    try {
      await safeFetch(`/api/admin/users/${userId}/status`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      fetchData();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div>
          <h1 className="text-3xl font-black text-zinc-900 flex items-center gap-3">
            <Shield className="text-emerald-600" /> Painel Master
          </h1>
          <p className="text-zinc-500">Gestão global da plataforma RifaPro.</p>
        </div>
        
        <div className="flex bg-white p-1 rounded-2xl border border-zinc-100 shadow-sm">
          <button 
            onClick={() => setActiveTab('stats')}
            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'stats' ? 'bg-zinc-900 text-white' : 'text-zinc-500 hover:text-zinc-900'}`}
          >
            Financeiro
          </button>
          <button 
            onClick={() => setActiveTab('users')}
            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'users' ? 'bg-zinc-900 text-white' : 'text-zinc-500 hover:text-zinc-900'}`}
          >
            Organizadores
          </button>
          <button 
            onClick={() => setActiveTab('settings')}
            className={`px-6 py-2 rounded-xl text-sm font-bold transition-all ${activeTab === 'settings' ? 'bg-zinc-900 text-white' : 'text-zinc-500 hover:text-zinc-900'}`}
          >
            Configurações
          </button>
        </div>
      </div>

      {activeTab === 'stats' && (
        <div className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
              <div className="w-12 h-12 bg-emerald-100 rounded-2xl flex items-center justify-center mb-4">
                <DollarSign className="text-emerald-600 w-6 h-6" />
              </div>
              <p className="text-zinc-400 text-xs font-bold uppercase tracking-widest mb-1">Volume Total</p>
              <p className="text-3xl font-black text-zinc-900">R$ {(stats?.total_revenue || 0).toFixed(2)}</p>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
              <div className="w-12 h-12 bg-blue-100 rounded-2xl flex items-center justify-center mb-4">
                <Users className="text-blue-600 w-6 h-6" />
              </div>
              <p className="text-zinc-400 text-xs font-bold uppercase tracking-widest mb-1">Organizadores</p>
              <p className="text-3xl font-black text-zinc-900">{stats?.total_organizers || 0}</p>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm">
              <div className="w-12 h-12 bg-purple-100 rounded-2xl flex items-center justify-center mb-4">
                <Ticket className="text-purple-600 w-6 h-6" />
              </div>
              <p className="text-zinc-400 text-xs font-bold uppercase tracking-widest mb-1">Rifas Criadas</p>
              <p className="text-3xl font-black text-zinc-900">{stats?.total_campaigns || 0}</p>
            </div>
            <div className="bg-white p-6 rounded-3xl border border-zinc-100 shadow-sm border-emerald-500 ring-4 ring-emerald-50">
              <div className="w-12 h-12 bg-emerald-600 rounded-2xl flex items-center justify-center mb-4">
                <TrendingUp className="text-white w-6 h-6" />
              </div>
              <p className="text-zinc-400 text-xs font-bold uppercase tracking-widest mb-1">Lucro Plataforma ({settings.platform_fee_percent || 0}%)</p>
              <p className="text-3xl font-black text-emerald-600">R$ {( (stats?.total_revenue || 0) * (parseFloat(settings.platform_fee_percent || '0') / 100) ).toFixed(2)}</p>
            </div>
          </div>
          
          <div className="bg-zinc-900 rounded-3xl p-8 text-white relative overflow-hidden">
            <div className="relative z-10">
              <h3 className="text-xl font-bold mb-2">Integração Mercado Pago</h3>
              <p className="text-zinc-400 text-sm max-w-md mb-6">O sistema está configurado para processar pagamentos via Mercado Pago. Todas as taxas são calculadas automaticamente.</p>
              <div className="flex gap-4">
                <div className="bg-white/10 px-4 py-2 rounded-xl border border-white/10">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Status API</p>
                  <p className="text-sm font-bold flex items-center gap-2">
                    <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span> Online
                  </p>
                </div>
                <div className="bg-white/10 px-4 py-2 rounded-xl border border-white/10">
                  <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-500">Split de Pagamento</p>
                  <p className="text-sm font-bold">Ativado</p>
                </div>
              </div>
            </div>
            <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-600/20 blur-[100px] rounded-full -mr-32 -mt-32"></div>
          </div>
        </div>
      )}

      {activeTab === 'users' && (
        <div className="bg-white rounded-3xl border border-zinc-100 overflow-hidden shadow-sm">
          <table className="w-full text-left">
            <thead className="bg-zinc-50 border-b border-zinc-100">
              <tr>
                <th className="px-6 py-4 text-xs font-bold text-zinc-400 uppercase tracking-widest">Organizador</th>
                <th className="px-6 py-4 text-xs font-bold text-zinc-400 uppercase tracking-widest">E-mail</th>
                <th className="px-6 py-4 text-xs font-bold text-zinc-400 uppercase tracking-widest">Status</th>
                <th className="px-6 py-4 text-xs font-bold text-zinc-400 uppercase tracking-widest">Cadastro</th>
                <th className="px-6 py-4 text-xs font-bold text-zinc-400 uppercase tracking-widest">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-50">
              {users.map(u => (
                <tr key={u.id} className="hover:bg-zinc-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-600 font-bold text-xs">
                        {u.name.charAt(0)}
                      </div>
                      <span className="font-bold text-zinc-900">{u.name}</span>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-sm text-zinc-500">{u.email}</td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider ${u.status === 'active' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'}`}>
                      {u.status === 'active' ? 'Ativo' : 'Suspenso'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-sm text-zinc-500">{new Date(u.created_at).toLocaleDateString()}</td>
                  <td className="px-6 py-4">
                    <div className="flex gap-4">
                      <button 
                        onClick={() => toggleUserStatus(u.id, u.status)}
                        className={`text-xs font-bold uppercase tracking-widest ${u.status === 'active' ? 'text-red-500 hover:text-red-700' : 'text-emerald-600 hover:text-emerald-700'}`}
                      >
                        {u.status === 'active' ? 'Suspender' : 'Ativar'}
                      </button>
                      <button 
                        onClick={() => {
                          // In a real app, this would filter the campaigns list or navigate
                          alert('Funcionalidade de ver campanhas do organizador em desenvolvimento.');
                        }}
                        className="text-xs font-bold uppercase tracking-widest text-zinc-400 hover:text-zinc-600"
                      >
                        Ver Rifas
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {activeTab === 'settings' && (
        <form onSubmit={handleUpdateSettings} className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-sm space-y-6">
            <h3 className="text-xl font-bold text-zinc-900 flex items-center gap-2">
              <LayoutDashboard className="w-5 h-5 text-emerald-600" /> Landing Page
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Nome do Site</label>
                <input 
                  type="text" 
                  className="w-full h-12 rounded-xl border border-zinc-200 px-4 font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                  value={settings.site_name || ''}
                  onChange={e => setSettings({...settings, site_name: e.target.value})}
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Descrição SEO</label>
                <textarea 
                  className="w-full h-24 rounded-xl border border-zinc-200 p-4 font-medium outline-none focus:ring-2 focus:ring-emerald-500 resize-none"
                  value={settings.site_description || ''}
                  onChange={e => setSettings({...settings, site_description: e.target.value})}
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Cor Primária</label>
                <div className="flex gap-4 items-center">
                  <input 
                    type="color" 
                    className="w-12 h-12 rounded-xl border border-zinc-200 p-1 outline-none"
                    value={settings.primary_color || '#059669'}
                    onChange={e => setSettings({...settings, primary_color: e.target.value})}
                  />
                  <span className="text-sm font-mono text-zinc-500">{settings.primary_color}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-sm space-y-6">
            <h3 className="text-xl font-bold text-zinc-900 flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-emerald-600" /> Pagamentos (Mercado Pago)
            </h3>
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Public Key</label>
                <input 
                  type="password" 
                  placeholder="APP_USR-..."
                  className="w-full h-12 rounded-xl border border-zinc-200 px-4 font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                  value={settings.mercadopago_public_key || ''}
                  onChange={e => setSettings({...settings, mercadopago_public_key: e.target.value})}
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Access Token</label>
                <input 
                  type="password" 
                  placeholder="TEST-..."
                  className="w-full h-12 rounded-xl border border-zinc-200 px-4 font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                  value={settings.mercadopago_access_token || ''}
                  onChange={e => setSettings({...settings, mercadopago_access_token: e.target.value})}
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Taxa da Plataforma (%)</label>
                <input 
                  type="number" 
                  className="w-full h-12 rounded-xl border border-zinc-200 px-4 font-medium outline-none focus:ring-2 focus:ring-emerald-500"
                  value={settings.platform_fee_percent ?? '5'}
                  onChange={e => setSettings({...settings, platform_fee_percent: e.target.value})}
                />
              </div>
            </div>
            <div className="pt-6">
              <button className="w-full bg-zinc-900 text-white py-4 rounded-2xl font-bold shadow-lg hover:bg-zinc-800 transition-all">
                Salvar Todas as Alterações
              </button>
            </div>
          </div>
        </form>
      )}
    </div>
  );
};

const Dashboard = ({ user, onSelectCampaign }: { user: User, onSelectCampaign: (c: Campaign) => void }) => {
  const [stats, setStats] = useState<any>(null);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [settingsTab, setSettingsTab] = useState<string | null>(null);
  const [selectedCampaignForManagement, setSelectedCampaignForManagement] = useState<Campaign | null>(null);
  const [showCreate, setShowCreate] = useState(false);

  const fetchData = async () => {
    if (!user?.id) return;
    try {
      const statsData = await safeFetch(`/api/admin/stats/${user.id}`);
      if (statsData) setStats(statsData);

      const campaignsData = await safeFetch(`/api/campaigns?organizer_id=${user.id}`);
      if (campaignsData) setCampaigns(campaignsData);
    } catch (err) {
      console.error('Erro ao buscar dados do dashboard:', err);
    }
  };

  useEffect(() => {
    fetchData();
  }, [user.id]);

  const handleManageCampaign = (c: Campaign) => {
    setSelectedCampaignForManagement(c);
    setActiveTab('manage-campaign');
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'manage-campaign':
        return selectedCampaignForManagement ? (
          <ManageCampaign 
            campaign={selectedCampaignForManagement} 
            onBack={() => setActiveTab('dashboard')} 
            onView={onSelectCampaign}
          />
        ) : null;
      case 'dashboard':
        return (
          <div className="space-y-12">
            <header>
              <h1 className="text-3xl font-black text-zinc-900 mb-2">Olá, {user.name}</h1>
              <p className="text-zinc-400 font-medium">Gerencie suas campanhas e acompanhe suas vendas.</p>
            </header>

            <section>
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-black text-zinc-900 flex items-center gap-2">
                  <TrendingUp className="text-brand-orange w-6 h-6" />
                  Relatório
                </h2>
                <div className="bg-white border border-zinc-100 rounded-xl px-4 py-2 flex items-center gap-2 text-xs font-bold text-zinc-400">
                  <Clock className="w-4 h-4" />
                  Filtro de data
                </div>
              </div>
              
              <div className="flex flex-wrap gap-6">
                <DashboardCard 
                  title="Visitas no site" 
                  value="0" 
                  icon={LayoutDashboard} 
                  colorClass="border-blue-500" 
                />
                <DashboardCard 
                  title="Vendas realizadas" 
                  value={`R$ ${(stats?.total_revenue || 0).toFixed(2)}`} 
                  subValue={`${stats?.tickets_sold || 0} Pedidos`}
                  icon={DollarSign} 
                  colorClass="border-brand-green" 
                />
                <DashboardCard 
                  title="Reservas" 
                  value="R$ 0,00" 
                  subValue="0 Pedidos"
                  icon={Clock} 
                  colorClass="border-brand-orange" 
                />
              </div>
            </section>

            <section>
              <h2 className="text-xl font-black text-zinc-900 flex items-center gap-2 mb-6">
                <Ticket className="text-brand-orange w-6 h-6" />
                Campanhas
              </h2>
              <div className="space-y-4">
                {campaigns.length > 0 ? (
                  campaigns.map(c => (
                    <CampaignRow key={c.id} campaign={c} onSelect={handleManageCampaign} isDashboard />
                  ))
                ) : (
                  <div className="glass-card p-12 text-center">
                    <p className="text-zinc-400 font-medium">Você ainda não possui campanhas.</p>
                    <button onClick={() => setShowCreate(true)} className="text-brand-orange font-bold mt-2">Criar minha primeira rifa</button>
                  </div>
                )}
              </div>
            </section>
          </div>
        );
      case 'my-campaigns':
        return (
          <div className="space-y-8">
            <header className="flex justify-between items-center">
              <h1 className="text-3xl font-black text-zinc-900">Minhas campanhas</h1>
              <div className="flex gap-4">
                <button className="bg-white border border-zinc-100 px-4 py-2 rounded-xl text-zinc-400 font-bold text-xs flex items-center gap-2"><Filter className="w-4 h-4" /> Filtros</button>
                <button onClick={() => setActiveTab('dashboard')} className="bg-white border border-zinc-100 px-4 py-2 rounded-xl text-zinc-400 font-bold text-xs flex items-center gap-2"><ArrowRight className="w-4 h-4 rotate-180" /> Voltar</button>
              </div>
            </header>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {campaigns.map(c => (
                <CampaignRow key={c.id} campaign={c} onSelect={handleManageCampaign} isDashboard />
              ))}
            </div>
          </div>
        );
      case 'supporters':
        return (
          <div className="space-y-8">
            <header className="flex justify-between items-center">
              <h1 className="text-3xl font-black text-zinc-900">Meus apoiadores</h1>
              <div className="flex gap-4">
                <div className="relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400 w-4 h-4" />
                  <input type="text" placeholder="Buscar..." className="bg-white border border-zinc-100 rounded-xl pl-10 pr-4 py-2 text-sm outline-none focus:ring-2 focus:ring-brand-orange" />
                </div>
                <button className="bg-white border border-zinc-100 p-2 rounded-xl text-zinc-400"><Upload className="w-5 h-5" /></button>
              </div>
            </header>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1,2,3,4,5,6].map(i => (
                <div key={i} className="glass-card p-6 space-y-4">
                  <h3 className="font-bold text-zinc-900">Apoiador Demo {i}</h3>
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-sm text-zinc-500">
                      <div className="bg-emerald-50 p-1.5 rounded-lg text-emerald-600"><TrendingUp className="w-4 h-4" /></div>
                      +55 11 99999-9999
                    </div>
                    <div className="flex items-center gap-2 text-sm text-zinc-500">
                      <div className="bg-blue-50 p-1.5 rounded-lg text-blue-600"><Users className="w-4 h-4" /></div>
                      apoiador{i}@demo.com
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      case 'settings':
        if (settingsTab === 'profile') return (
          <div className="space-y-8">
            <header className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-orange-50 rounded-2xl text-brand-orange">
                  <SettingsIcon className="w-6 h-6" />
                </div>
                <h1 className="text-3xl font-black text-zinc-900">Configuração / <span className="text-zinc-400">Minha conta</span></h1>
              </div>
              <button onClick={() => setSettingsTab(null)} className="bg-white border border-zinc-100 px-6 py-3 rounded-2xl text-zinc-400 font-bold text-sm flex items-center gap-2 hover:border-zinc-300 transition-all">
                <ChevronRight className="w-4 h-4 rotate-180" /> Voltar
              </button>
            </header>

            <div className="glass-card p-10 space-y-10">
              <div className="flex flex-col items-center gap-4">
                <div className="relative">
                  <div className="w-32 h-32 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-300">
                    <UserIcon className="w-16 h-16" />
                  </div>
                  <button className="absolute bottom-0 right-0 p-2 bg-emerald-600 text-white rounded-full border-4 border-white">
                    <Edit3 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Nome Completo</label>
                  <div className="relative">
                    <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-orange w-5 h-5" />
                    <input type="text" defaultValue={user.name} className="w-full h-14 bg-zinc-50 border border-zinc-100 rounded-2xl pl-12 pr-4 font-medium outline-none focus:ring-2 focus:ring-brand-orange" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Endereço de email</label>
                  <div className="relative">
                    <ShoppingBag className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-orange w-5 h-5" />
                    <input type="email" defaultValue={user.email} className="w-full h-14 bg-zinc-50 border border-zinc-100 rounded-2xl pl-12 pr-12 font-medium outline-none focus:ring-2 focus:ring-brand-orange" />
                    <Edit3 className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-300 w-4 h-4" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Celular com DDD</label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
                      <span className="text-xl">🇧🇷</span>
                      <span className="text-zinc-400 font-bold">+ 55</span>
                    </div>
                    <input type="text" className="w-full h-14 bg-zinc-50 border border-zinc-100 rounded-2xl pl-24 pr-4 font-medium outline-none focus:ring-2 focus:ring-brand-orange" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Senha</label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-1">
                      <div className="w-2 h-2 bg-brand-orange rounded-full" />
                      <div className="w-2 h-2 bg-brand-orange rounded-full" />
                    </div>
                    <input type="password" placeholder="********" className="w-full h-14 bg-zinc-50 border border-zinc-100 rounded-2xl pl-12 pr-12 font-medium outline-none focus:ring-2 focus:ring-brand-orange" />
                    <Eye className="absolute right-4 top-1/2 -translate-y-1/2 text-brand-orange w-5 h-5" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">Confirmar senha</label>
                  <div className="relative">
                    <div className="absolute left-4 top-1/2 -translate-y-1/2 flex items-center gap-1">
                      <div className="w-2 h-2 bg-brand-orange rounded-full" />
                      <div className="w-2 h-2 bg-brand-orange rounded-full" />
                    </div>
                    <input type="password" placeholder="********" className="w-full h-14 bg-zinc-50 border border-zinc-100 rounded-2xl pl-12 pr-12 font-medium outline-none focus:ring-2 focus:ring-brand-orange" />
                    <Eye className="absolute right-4 top-1/2 -translate-y-1/2 text-brand-orange w-5 h-5" />
                  </div>
                </div>
              </div>

              <button className="w-full bg-brand-orange text-white py-5 rounded-2xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-600 transition-all">
                Salvar
              </button>

              <div className="pt-10 border-t border-zinc-100">
                <div className="glass-card p-6 flex items-center justify-between hover:bg-zinc-50 cursor-pointer transition-all group">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-red-50 flex items-center justify-center text-red-500">
                      <X className="w-6 h-6" />
                    </div>
                    <div>
                      <h3 className="font-bold text-zinc-900">Excluir conta</h3>
                      <p className="text-sm text-zinc-400">Exclua seus dados cadastrais por completo</p>
                    </div>
                  </div>
                  <ChevronRight className="text-zinc-300 group-hover:text-zinc-500 transition-all" />
                </div>
              </div>
            </div>
          </div>
        );

        if (settingsTab === 'payments') return (
          <div className="space-y-8">
            <header className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-orange-50 rounded-2xl text-brand-orange">
                  <SettingsIcon className="w-6 h-6" />
                </div>
                <h1 className="text-3xl font-black text-zinc-900">Configuração / <span className="text-zinc-400">Adicionar um meio de pagamento</span></h1>
              </div>
              <button onClick={() => setSettingsTab(null)} className="bg-white border border-zinc-100 px-6 py-3 rounded-2xl text-zinc-400 font-bold text-sm flex items-center gap-2 hover:border-zinc-300 transition-all">
                <ChevronRight className="w-4 h-4 rotate-180" /> Voltar
              </button>
            </header>

            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-black text-zinc-900 mb-2">Adicionar meios de pagamento</h2>
                <p className="text-zinc-400 font-medium">Adicione um meio de pagamento e receba diretamente em sua conta</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {[
                  { name: 'XGATE', color: 'bg-black text-white' },
                  { name: 'Getpay', color: 'text-blue-600' },
                  { name: 'Suit', color: 'bg-emerald-500 text-white' },
                  { name: 'efi BANK', color: 'text-orange-600' },
                  { name: 'pago express', color: 'text-zinc-900' },
                  { name: 'Pay2m', color: 'text-blue-500' },
                ].map((p, i) => (
                  <div key={i} className="glass-card p-8 space-y-6 hover:border-brand-orange transition-all cursor-pointer group">
                    <div className={`h-12 w-24 flex items-center justify-center font-black text-lg rounded-lg ${p.color}`}>
                      {p.name}
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="p-1.5 bg-emerald-50 rounded-lg text-emerald-500">
                        <TrendingUp className="w-4 h-4" />
                      </div>
                      <p className="text-sm font-bold text-zinc-600 leading-tight">Meio de pagamento com baixa automática</p>
                    </div>
                  </div>
                ))}
                
                <div 
                  onClick={() => setSettingsTab('pix-config')}
                  className="glass-card p-8 space-y-6 hover:border-brand-orange transition-all cursor-pointer group"
                >
                  <div className="h-12 w-24 flex items-center justify-center font-black text-lg rounded-lg text-emerald-500">
                    pix
                  </div>
                  <div className="flex items-start gap-3">
                    <div className="p-1.5 bg-orange-50 rounded-lg text-brand-orange">
                      <AlertCircle className="w-4 h-4" />
                    </div>
                    <p className="text-sm font-bold text-zinc-600 leading-tight">Você terá que aprovar a compra de forma manual</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

        if (settingsTab === 'pix-config') return (
          <div className="fixed inset-0 z-[100] flex items-center justify-end p-4 bg-black/40 backdrop-blur-sm">
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              className="bg-white h-full w-full max-w-xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col"
            >
              <div className="p-8 border-b border-zinc-100 flex items-center justify-between">
                <h2 className="text-2xl font-black text-zinc-900">Gerenciar Chaves Pix</h2>
                <button onClick={() => setSettingsTab('payments')} className="bg-white border border-zinc-100 px-6 py-3 rounded-2xl text-zinc-400 font-bold text-sm flex items-center gap-2 hover:border-zinc-300 transition-all">
                  <ChevronRight className="w-4 h-4 rotate-180" /> Voltar
                </button>
              </div>
              
              <div className="p-8 flex-1 space-y-8">
                <button className="w-full py-4 border-2 border-blue-100 rounded-2xl text-blue-600 font-bold flex items-center justify-center gap-2 hover:bg-blue-50 transition-all">
                  <Play className="w-4 h-4 fill-current" /> Veja como funciona!
                </button>

                <div className="space-y-6">
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Nome do titular</label>
                    <input type="text" placeholder="Nome do titular" className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange" />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Qual o tipo de chave?</label>
                    <select className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange appearance-none bg-white">
                      <option>Chave aleatória</option>
                      <option>CPF</option>
                      <option>Email</option>
                      <option>Celular</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Informe a chave pix</label>
                    <textarea placeholder="c234c234c3-c423c4234c2-4c234c234..." className="w-full h-32 rounded-2xl border border-zinc-200 p-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange resize-none" />
                  </div>
                </div>
              </div>

              <div className="p-8 border-t border-zinc-100 flex gap-4">
                <button onClick={() => setSettingsTab('payments')} className="flex-1 h-14 border-2 border-zinc-100 rounded-2xl font-bold text-zinc-400 hover:bg-zinc-50 transition-all">Cancelar</button>
                <button className="flex-1 h-14 bg-brand-orange text-white rounded-2xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-600 transition-all">Salvar</button>
              </div>
            </motion.div>
          </div>
        );

        if (settingsTab === 'social') return (
          <div className="space-y-8">
            <header className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-orange-50 rounded-2xl text-brand-orange">
                  <SettingsIcon className="w-6 h-6" />
                </div>
                <h1 className="text-3xl font-black text-zinc-900">Configuração / <span className="text-zinc-400">Adicionar redes sociais</span></h1>
              </div>
              <button onClick={() => setSettingsTab(null)} className="bg-white border border-zinc-100 px-6 py-3 rounded-2xl text-zinc-400 font-bold text-sm flex items-center gap-2 hover:border-zinc-300 transition-all">
                <ChevronRight className="w-4 h-4 rotate-180" /> Voltar
              </button>
            </header>

            <div className="glass-card p-10 space-y-10">
              <h2 className="text-2xl font-black text-zinc-900">Atendimento e redes sociais</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {[
                  { label: 'Número para suporte', icon: '🇧🇷 + 55', type: 'tel' },
                  { label: 'Link do grupo Whatsapp', icon: UserIcon, placeholder: 'Link do canal ou grupo' },
                  { label: 'Link do grupo Telegram', icon: Play, placeholder: 'Link do canal ou grupo' },
                  { label: 'Instagram', icon: ImageIcon, placeholder: '@seuperfil' },
                  { label: 'Tiktok', icon: RotateCcw, placeholder: 'Link do seu perfil' },
                  { label: 'Youtube', icon: Play, placeholder: 'Link do seu perfil' },
                  { label: 'Facebook', icon: Users, placeholder: 'Link do seu perfil' },
                ].map((item, i) => (
                  <div key={i} className="space-y-2">
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest">{item.label}</label>
                    <div className="flex items-center gap-4">
                      <div className="relative flex-1">
                        {typeof item.icon === 'string' ? (
                          <div className="absolute left-4 top-1/2 -translate-y-1/2 font-bold text-zinc-400">{item.icon}</div>
                        ) : (
                          <item.icon className="absolute left-4 top-1/2 -translate-y-1/2 text-brand-orange w-5 h-5" />
                        )}
                        <input type="text" placeholder={item.placeholder} className={`w-full h-14 bg-zinc-50 border border-zinc-100 rounded-2xl ${typeof item.icon === 'string' ? 'pl-20' : 'pl-12'} pr-4 font-medium outline-none focus:ring-2 focus:ring-brand-orange`} />
                      </div>
                      <div className="w-12 h-6 bg-zinc-100 rounded-full relative cursor-pointer">
                        <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <button className="w-full bg-brand-orange text-white py-5 rounded-2xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-600 transition-all">
                Confirmar
              </button>
            </div>
          </div>
        );

        if (settingsTab === 'integrations') return (
          <div className="space-y-8">
            <header className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-orange-50 rounded-2xl text-brand-orange">
                  <SettingsIcon className="w-6 h-6" />
                </div>
                <h1 className="text-3xl font-black text-zinc-900">Configuração / <span className="text-zinc-400">Integrações</span></h1>
              </div>
              <button onClick={() => setSettingsTab(null)} className="bg-white border border-zinc-100 px-6 py-3 rounded-2xl text-zinc-400 font-bold text-sm flex items-center gap-2 hover:border-zinc-300 transition-all">
                <ChevronRight className="w-4 h-4 rotate-180" /> Voltar
              </button>
            </header>

            <div className="space-y-8">
              <h2 className="text-2xl font-black text-zinc-900">Anúncios e monitoramento</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div 
                  onClick={() => setSettingsTab('pixel-config')}
                  className="glass-card p-12 flex items-center justify-center gap-4 hover:border-brand-orange transition-all cursor-pointer group"
                >
                  <span className="text-2xl font-black text-blue-600">facebook</span>
                  <Plus className="text-zinc-300" />
                  <span className="text-2xl font-black text-zinc-900 italic">Instagram</span>
                </div>
                <div 
                  onClick={() => setSettingsTab('analytics-config')}
                  className="glass-card p-12 flex items-center justify-center gap-4 hover:border-brand-orange transition-all cursor-pointer group"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 bg-yellow-400 rounded-lg flex items-center justify-center text-white font-black">G</div>
                    <span className="text-2xl font-black text-zinc-900">Google Analytics</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        );

        if (settingsTab === 'pixel-config' || settingsTab === 'analytics-config') return (
          <div className="fixed inset-0 z-[100] flex items-center justify-end p-4 bg-black/40 backdrop-blur-sm">
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              className="bg-white h-full w-full max-w-xl rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col"
            >
              <div className="p-8 border-b border-zinc-100 flex items-center justify-between">
                <h2 className="text-2xl font-black text-zinc-900">
                  {settingsTab === 'pixel-config' ? 'Configuração do pixel' : 'Configuração do Analytics'}
                </h2>
                <button onClick={() => setSettingsTab('integrations')} className="bg-white border border-zinc-100 px-6 py-3 rounded-2xl text-zinc-400 font-bold text-sm flex items-center gap-2 hover:border-zinc-300 transition-all">
                  <ChevronRight className="w-4 h-4 rotate-180" /> Voltar
                </button>
              </div>
              
              <div className="p-8 flex-1 space-y-8">
                <button className="w-full py-4 border-2 border-blue-100 rounded-2xl text-blue-600 font-bold flex items-center justify-center gap-2 hover:bg-blue-50 transition-all">
                  <Play className="w-4 h-4 fill-current" /> Veja como funciona!
                </button>

                <div className="flex flex-col items-center gap-6 py-10">
                  {settingsTab === 'pixel-config' ? (
                    <div className="flex items-center gap-4">
                      <span className="text-4xl font-black text-blue-600">facebook</span>
                      <Plus className="text-zinc-300 w-8 h-8" />
                      <span className="text-4xl font-black text-zinc-900 italic">Instagram</span>
                    </div>
                  ) : (
                    <div className="flex items-center gap-4">
                      <div className="w-16 h-16 bg-yellow-400 rounded-2xl flex items-center justify-center text-white font-black text-3xl">G</div>
                      <span className="text-4xl font-black text-zinc-900">Google Analytics</span>
                    </div>
                  )}
                </div>

                <div className="space-y-6">
                  <div>
                    <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">
                      {settingsTab === 'pixel-config' ? 'ID do Pixel do Facebook' : 'ID da métrica'}
                    </label>
                    <input 
                      type="text" 
                      placeholder={settingsTab === 'pixel-config' ? 'Ex: 1234567890' : 'G-DXHERPQHBX'} 
                      className="w-full h-14 rounded-2xl border border-zinc-200 px-6 font-medium outline-none focus:ring-2 focus:ring-brand-orange" 
                    />
                  </div>
                </div>
              </div>

              <div className="p-8 border-t border-zinc-100">
                <button className="w-full h-14 bg-brand-orange text-white rounded-2xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-600 transition-all">Continuar</button>
              </div>
            </motion.div>
          </div>
        );

        if (settingsTab === 'personalize') return (
          <div className="space-y-8">
            <header className="flex justify-between items-center">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-orange-50 rounded-2xl text-brand-orange">
                  <SettingsIcon className="w-6 h-6" />
                </div>
                <h1 className="text-3xl font-black text-zinc-900">Personalizar</h1>
              </div>
              <button onClick={() => setSettingsTab(null)} className="bg-white border border-zinc-100 px-6 py-3 rounded-2xl text-zinc-400 font-bold text-sm flex items-center gap-2 hover:border-zinc-300 transition-all">
                <ChevronRight className="w-4 h-4 rotate-180" /> Voltar
              </button>
            </header>

            <div className="space-y-6">
              <button className="w-full py-4 border-2 border-blue-100 rounded-2xl text-blue-600 font-bold flex items-center justify-center gap-2 hover:bg-blue-50 transition-all">
                <Play className="w-4 h-4 fill-current" /> Veja como funciona!
              </button>

              <div className="glass-card divide-y divide-zinc-100">
                <div className="p-6 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-orange-50 rounded-xl text-brand-orange">
                      <RotateCcw className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-zinc-900">Tema do site</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-6 bg-zinc-100 rounded-full relative cursor-pointer">
                      <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm" />
                    </div>
                    <span className="text-sm font-bold text-zinc-400">Light</span>
                  </div>
                </div>

                <div className="p-6 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-orange-50 rounded-xl text-brand-orange">
                      <ImageIcon className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-zinc-900">Cor principal</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-6 h-6 bg-brand-orange rounded-full" />
                    <span className="text-sm font-bold text-zinc-400">Selecione</span>
                  </div>
                </div>

                <div className="p-6 flex items-center justify-between cursor-pointer hover:bg-zinc-50 transition-all group">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-orange-50 rounded-xl text-brand-orange">
                      <ShoppingBag className="w-5 h-5" />
                    </div>
                    <span className="font-bold text-zinc-900">Adicionar um domínio</span>
                  </div>
                  <ChevronRight className="text-zinc-300 group-hover:text-zinc-500 transition-all" />
                </div>
              </div>

              <div className="glass-card overflow-hidden">
                <div className="flex border-b border-zinc-100">
                  <button className="flex-1 py-4 text-sm font-bold text-brand-orange border-b-2 border-brand-orange">Logotipo</button>
                  <button className="flex-1 py-4 text-sm font-bold text-zinc-400">Ícone da página</button>
                </div>
                <div className="p-10 space-y-8">
                  <div className="flex items-center gap-3">
                    <ImageIcon className="text-brand-orange w-5 h-5" />
                    <span className="text-sm font-bold text-zinc-900">Adicione a sua logo</span>
                  </div>
                  
                  <div className="flex items-center justify-between gap-10">
                    <div className="flex items-center gap-2">
                      <span className="text-2xl font-black text-emerald-500">RIFA</span>
                      <div className="bg-brand-orange text-white px-2 py-1 rounded-lg font-black text-xl">321</div>
                    </div>
                    
                    <div className="w-32 h-20 border-2 border-dashed border-zinc-200 rounded-2xl flex flex-col items-center justify-center gap-2 text-zinc-300 hover:border-brand-orange hover:text-brand-orange transition-all cursor-pointer">
                      <Upload className="w-6 h-6" />
                      <span className="text-[10px] font-bold">Adicionar</span>
                    </div>
                  </div>
                </div>
              </div>

              <button className="w-full bg-brand-orange text-white py-5 rounded-2xl font-bold shadow-lg shadow-orange-100 hover:bg-orange-600 transition-all">
                Salvar
              </button>
            </div>
          </div>
        );

        return (
          <div className="space-y-12">
            <h1 className="text-3xl font-black text-zinc-900">Configuração</h1>
            
            <div 
              onClick={() => setSettingsTab('profile')}
              className="glass-card p-6 flex items-center justify-between hover:bg-zinc-50 cursor-pointer transition-all group"
            >
              <div className="flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-400">
                  <UserIcon className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="font-bold text-zinc-900">{user.name}</h3>
                  <p className="text-sm text-zinc-400">Gerencie informações e segurança da sua conta</p>
                </div>
              </div>
              <ChevronRight className="text-zinc-300 group-hover:text-zinc-500 transition-all" />
            </div>

            <section>
              <h2 className="text-xl font-black text-zinc-900 mb-6">Recursos</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {[
                  { label: 'Adicionar conta bancária', icon: DollarSign, tab: 'payments' },
                  { label: 'Personalize do seu jeito', icon: SettingsIcon, tab: 'personalize' },
                  { label: 'Adicionar redes sociais', icon: Users, tab: 'social' },
                  { label: 'Integrações avançadas', icon: QrCode, tab: 'integrations' },
                ].map((item, i) => (
                  <div 
                    key={i} 
                    onClick={() => setSettingsTab(item.tab)}
                    className="glass-card p-8 flex flex-col items-center text-center gap-4 hover:border-brand-orange transition-all cursor-pointer group"
                  >
                    <div className="p-4 bg-zinc-50 rounded-2xl group-hover:bg-orange-50 transition-all">
                      <item.icon className="w-8 h-8 text-brand-orange" />
                    </div>
                    <p className="text-sm font-bold text-zinc-900 leading-tight">{item.label}</p>
                  </div>
                ))}
              </div>
            </section>
          </div>
        );
      case 'support':
        return (
          <div className="space-y-12">
            <h1 className="text-3xl font-black text-zinc-900">Ajuda</h1>
            <p className="text-xl font-bold text-zinc-600">Em que podemos ajuda-lo hoje?</p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="glass-card p-10 flex items-center gap-8 hover:border-emerald-500 transition-all cursor-pointer group">
                <div className="p-5 bg-emerald-50 rounded-3xl text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-all">
                  <Users className="w-10 h-10" />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-zinc-900 mb-2">Whatsapp</h3>
                  <p className="text-zinc-400 font-medium">Atendimento de Segunda a Sábado das 9:00 às 22:00</p>
                </div>
              </div>
              <div className="glass-card p-10 flex items-center gap-8 hover:border-brand-orange transition-all cursor-pointer group">
                <div className="p-5 bg-orange-50 rounded-3xl text-brand-orange group-hover:bg-brand-orange group-hover:text-white transition-all">
                  <Shield className="w-10 h-10" />
                </div>
                <div>
                  <h3 className="text-2xl font-black text-zinc-900 mb-2">Central de ajuda</h3>
                  <p className="text-zinc-400 font-medium">Tire todas as suas dúvidas Atendimento 24h 7 dias por semana</p>
                </div>
              </div>
            </div>
          </div>
        );
      default:
        return <div className="p-12 text-center text-zinc-400">Em breve...</div>;
    }
  };

  return (
    <div className="flex min-h-screen bg-brand-bg">
      <AnimatePresence>
        {showCreate && (
          <CreateCampaignModal 
            user={user} 
            onClose={() => setShowCreate(false)} 
            onCreated={fetchData} 
          />
        )}
      </AnimatePresence>
      <Sidebar 
        activeTab={activeTab} 
        onNavigate={(tab) => {
          if (tab === 'create-campaign') {
            setShowCreate(true);
          } else {
            setActiveTab(tab);
          }
        }} 
        onLogout={() => window.location.reload()} 
        user={user} 
      />
      <main className="flex-1 p-12 overflow-y-auto">
        {renderContent()}
      </main>
    </div>
  );
};

const LoginPage = ({ onLogin }: { onLogin: (u: User) => void }) => {
  const [email, setEmail] = useState('admin@rifapro.com');
  const [password, setPassword] = useState('password123');

  const handleLogin = async (emailToLogin: string, passwordToLogin: string) => {
    try {
      const data = await safeFetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: emailToLogin, password: passwordToLogin })
      });
      
      if (data && data.success) {
        onLogin(data.user);
      } else {
        alert(data?.message || 'Falha na autenticação. Verifique seus dados.');
      }
    } catch (err: any) {
      alert(err.message || 'Erro ao conectar com o servidor. Tente novamente em instantes.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleLogin(email, password);
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white p-8 rounded-3xl border border-zinc-100 shadow-2xl w-full max-w-md"
      >
        <div className="text-center mb-8">
          <div className="w-16 h-16 bg-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Ticket className="text-white w-8 h-8" />
          </div>
          <h1 className="text-2xl font-black text-zinc-900">Bem-vindo de volta</h1>
          <p className="text-zinc-500 text-sm">Acesse sua conta para gerenciar suas rifas.</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">E-mail</label>
            <input 
              type="email" 
              className="w-full h-12 rounded-xl border border-zinc-200 px-4 font-medium outline-none focus:ring-2 focus:ring-emerald-500"
              value={email}
              onChange={e => setEmail(e.target.value)}
            />
          </div>
          <div>
            <label className="text-xs font-bold text-zinc-400 uppercase tracking-widest mb-2 block">Senha</label>
            <input 
              type="password" 
              className="w-full h-12 rounded-xl border border-zinc-200 px-4 font-medium outline-none focus:ring-2 focus:ring-emerald-500"
              value={password}
              onChange={e => setPassword(e.target.value)}
            />
          </div>
          <button className="w-full bg-emerald-600 text-white py-4 rounded-2xl font-bold shadow-lg shadow-emerald-100 hover:bg-emerald-700 transition-all">
            Entrar no Painel
          </button>
        </form>

        <div className="mt-8 pt-8 border-t border-zinc-100">
          <p className="text-center text-xs font-bold text-zinc-400 uppercase tracking-widest mb-4">Acesso Rápido (Demo)</p>
          <div className="grid grid-cols-2 gap-3">
            <button 
              onClick={() => handleLogin('admin@rifapro.com', 'password123')}
              className="py-2 px-4 rounded-xl border border-zinc-200 text-xs font-bold text-zinc-600 hover:border-emerald-600 hover:text-emerald-600 transition-all"
            >
              Admin Demo
            </button>
            <button 
              onClick={() => handleLogin('user@demo.com', 'password123')}
              className="py-2 px-4 rounded-xl border border-zinc-200 text-xs font-bold text-zinc-600 hover:border-emerald-600 hover:text-emerald-600 transition-all"
            >
              User Demo
            </button>
          </div>
        </div>

        <p className="text-center text-xs text-zinc-400 mt-8">
          Ainda não tem conta? <span className="text-emerald-600 font-bold cursor-pointer">Crie sua primeira rifa agora.</span>
        </p>
      </motion.div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [page, setPage] = useState('home');
  const [user, setUser] = useState<User | null>(null);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [selectedCampaign, setSelectedCampaign] = useState<Campaign | null>(null);

  useEffect(() => {
    safeFetch('/api/campaigns').then(data => {
      if (data) setCampaigns(data);
    }).catch(err => {
      console.error('Erro ao carregar campanhas iniciais:', err);
    });
  }, []);

  const handleLogin = (u: User) => {
    setUser(u);
    setPage('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setPage('home');
  };

  const handleSelectCampaign = (c: Campaign) => {
    setSelectedCampaign(c);
    setPage('campaign-details');
  };

  const isDashboard = page === 'dashboard' && user;

  return (
    <div className="min-h-screen bg-zinc-50 font-sans selection:bg-emerald-100 selection:text-emerald-900">
      {!isDashboard && <Navbar user={user} onLogout={handleLogout} onNavigate={setPage} />}

      <main>
        <AnimatePresence mode="wait">
          {page === 'home' && (
            <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <HomePage campaigns={campaigns} onSelectCampaign={handleSelectCampaign} />
            </motion.div>
          )}

          {page === 'campaign-details' && selectedCampaign && (
            <motion.div key="details" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <CampaignDetails campaign={selectedCampaign} onBack={() => setPage('home')} />
            </motion.div>
          )}

          {page === 'login' && (
            <motion.div key="login" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              <LoginPage onLogin={handleLogin} />
            </motion.div>
          )}

          {page === 'dashboard' && user && (
            <motion.div key="dashboard" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
              {user.role === 'super_admin' ? <SuperAdminDashboard user={user} /> : <Dashboard user={user} onSelectCampaign={handleSelectCampaign} />}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {!isDashboard && (
        <footer className="bg-white border-t border-zinc-100 py-12 mt-24">
          <div className="max-w-7xl mx-auto px-4 text-center">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="bg-zinc-900 p-1.5 rounded-lg">
                <Ticket className="text-white w-4 h-4" />
              </div>
              <span className="text-lg font-bold tracking-tight text-zinc-900">RifaPro SaaS</span>
            </div>
            <p className="text-zinc-400 text-sm">© 2024 RifaPro. A plataforma líder em sorteios online auditáveis.</p>
            <div className="flex justify-center gap-6 mt-6">
              <a href="#" className="text-xs font-bold text-zinc-400 hover:text-zinc-900 uppercase tracking-widest">Termos</a>
              <a href="#" className="text-xs font-bold text-zinc-400 hover:text-zinc-900 uppercase tracking-widest">Privacidade</a>
              <a href="#" className="text-xs font-bold text-zinc-400 hover:text-zinc-900 uppercase tracking-widest">Ajuda</a>
            </div>
          </div>
        </footer>
      )}
    </div>
  );
}
